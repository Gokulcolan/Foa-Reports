import React from "react";
import CommonDatePicker from "./datePicker";
import CommonDropdown from "./commonDropDown";
import { Button, Alert } from "@mui/material";


const ComponentHeadBar = ({ mainHeading,
  shiftOptions,
  partNumberOptions,
  // selectedDate,
  selectedShift,
  selectedPartNumber,
  handleDateChange,
  handleShiftChange,
  handlePartNumberChange,
  handleViewTable,
  Error, }) => {

  // const [selectedShift, setSelectedShift] = useState("");
  // const [selectedDate, setSelectedDate] = useState(null);
  // const [selectedPartNumber, setSelectedPartNumber] = useState("");
  // const [error, setError] = useState(""); // State to track errors

  // const { partNumberDetail } = useSelector(userSelector);

  // const dispatch = useDispatch();

  // const ShiftOptions = [
  //   { value: "A", label: "A" },
  //   { value: "B", label: "B" },
  //   { value: "C", label: "C" },
  // ];

  // const partNumberOptions = (partNumberDetail?.varieties || []).map((item) => ({
  //   value: item,
  //   label: item,
  // }));

  // useEffect(() => {
  //   if (selectedShift && selectedDate) {
  //     const payload = {
  //       // type: "varieties",
  //       date: selectedDate,
  //       shift: selectedShift,
  //     };
  //     dispatch(partNumberApi(payload));
  //   }
  // }, [selectedShift, selectedDate, dispatch]);

  // useEffect(() => {
  //   if (
  //     selectedPartNumber &&
  //     !partNumberOptions.some((option) => option.value === selectedPartNumber)
  //   ) {
  //     setSelectedPartNumber(""); // Reset if the value is not in the new options
  //   } else {
  //     console.log("Keeping Selected Part Number:", selectedPartNumber);
  //   }
  // }, [partNumberOptions, selectedPartNumber]);

  // const handleDateChange = (date) => {
  //   setSelectedDate(date?.format("YYYY-MM-DD"));
  // };

  // const handleChange = (value) => {
  //   setSelectedPartNumber(value);
  // };

  // const handleViewTable = () => {
  //   if (!selectedDate || !selectedShift || !selectedPartNumber) {
  //     setError("Please select all the fields before viewing the table.");
  //   } else {
  //     setError(""); // Clear error message
  //   }
  //   const payload = {
  //     // type: "data",
  //     date: selectedDate,
  //     shift: selectedShift,
  //     variety: selectedPartNumber,
  //   };
  //   dispatch(foaDataApi(payload));
  // };

  return (
    <div>
      <div>
        <h2
          style={{
            textAlign: "center",
            textTransform: "uppercase",
            color: "rgb(0, 87, 172)",
            fontSize: "32px",
          }}
        >
          {mainHeading}
        </h2>
      </div>
      <br />
      <div
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        <CommonDatePicker onChange={handleDateChange} />
        <CommonDropdown
          label="Shift"
          options={shiftOptions}
          value={selectedShift}
          sx={{ width: "300px", margin: "0px 20px" }}
          customChange={handleShiftChange}
        />
        <CommonDropdown
          label="Part Number"
          options={partNumberOptions?.length === 0 ? [{ value: "", label: "No Data Found" }] : partNumberOptions}
          value={selectedPartNumber}
          sx={{ width: "300px", margin: "0px 20px" }}
          customChange={handlePartNumberChange}
        />
        <div style={{ margin: "10px 20px" }}>
          <Button variant="contained" onClick={handleViewTable}>
            View
          </Button>
        </div>
      </div>
      <br />
      {Error && <Alert severity="error">{Error}</Alert>} {/* Error message */}
    </div>
  );
};

export default ComponentHeadBar;
