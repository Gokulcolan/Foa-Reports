import React from 'react'
import Backdrop from '@mui/material/Backdrop';
import { useSelector } from "react-redux";
import { userSelector } from "../../redux/slice/userSlice";

const LazyLoader = () => {
  const { globalIsLoading } = useSelector(userSelector);
  return (
    <div>
      <Backdrop
        sx={{
          color: 'green',
          zIndex: (theme) => theme.zIndex.drawer + 1,
          height: "100vh",
          width: "100vw",
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
        }}
        open={globalIsLoading}
      >
        <div className="loader__wrap">
          <div className="spinner"></div>
        </div>
      </Backdrop>
    </div>
  )
}

export default LazyLoader
