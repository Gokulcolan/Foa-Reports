import { useRoutes } from "react-router-dom";
import { getRoutes } from "../layout/routes";
import React, { Suspense } from "react";
import LazyLoader from "../components/Loader/lazyLoader"

function App() {
  const userRole =
    typeof window !== "undefined" ? sessionStorage.getItem("ur") : null;
  const routeType = userRole !== null ? userRole : 0;

  // Fetch the routes based on the role
  const router = useRoutes(getRoutes(routeType));

  return (
    <div className="App">
      <Suspense fallback={<LazyLoader />}>
        {router}
      </Suspense>
    </div>
  );
}

export default App;
