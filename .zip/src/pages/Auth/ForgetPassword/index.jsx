import React from 'react'

const ForgotPassword = () => {
  return (
    <div>ForgetPassword</div>
  )
}

export default ForgotPassword