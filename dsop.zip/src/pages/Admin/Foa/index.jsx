import React from 'react'

const FoaAdmin = () => {
  return (
    <div>Master Admin</div>
  )
}

export default FoaAdmin