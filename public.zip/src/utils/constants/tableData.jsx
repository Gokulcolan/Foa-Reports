export const headers = [
  [
    {
      label: "M70 PRD/3 YTB STARTER MOTOR  ",
      colSpan: 6,
    },
    { label: "DATE:", colSpan: 4 },
  ],
  [
    { label: "FIRST OFF APPROVAL REPORT", colSpan: 6 },
    { label: "SHIFT:", colSpan: 4 }, // Static label for Shift
  ],
  [
    { label: "MODULE : GRS LD MAIN ASSY", colSpan: 6 },
    { label: "CUSTOMER:", colSpan: 4 },
  ],
  [
    { label: "NOTE", rowSpan: 1 },
    { label: "Shift change over", colSpan: 2 },
    { label: "Product change over", rowSpan: 1 },
    { label: "Tool change over", rowSpan: 1 },
    { label: "Power failure", rowSpan: 1 },
    { label: "Breakdown (P/Y or M/c or Tool)", colSpan: 2 },
    { label: "Shut down", rowSpan: 1 },
    { label: "Last off", rowSpan: 1 },
  ],
  [
    { label: "Process No", rowSpan: 2, id: "Process_Number" },
    {
      label: "Process Name / Opn. description",
      rowSpan: 2,
      id: "Process_Name",
    },
    {
      label: "Product Characteristics",
      rowSpan: 2,
      id: "Product_Characteristics",
    },
    {
      label: "Specification / Tolerance",
      rowSpan: 2,
      id: "Specifications_Tolerance",
    },
    {
      label: "Evaluation / Measurement method",
      rowSpan: 2,
      id: "Evaluation_Measurement_method",
    },
    { label: "Actual", colSpan: 5 },
  ],
  [
    { label: "1", id: "AO_1" },
    { label: "2", id: "AO_2" },
    { label: "3", id: "AO_3" },
    { label: "4", id: "AO_4" },
    { label: "5", id: "AO_5" },
  ],
];

export const footer = [
  [
    {
      label: "Remarks - ",
      colSpan: 2,
    },
    {
      label: "QualityAuditor -",
      colSpan: 2,
    },
    {
      label: "QualityVerifier -",
      colSpan: 3,
    },
    {
      label: "Time -",
      colSpan: 3,
    },
  ],
];

export const PokeYokeChecklistHeaders = [
  [
    {
      label: "POKA YOKE CHECK LIST - MGRS M70 -PSSF (YED) MAIN ASSEMBLY NEW LINE",
      colSpan: 4, // This spans across the entire table
    },
    { 
      label: "DATE:", 
      colSpan: 2 
    },
    { 
      label: "SHIFT:", 
      colSpan: 1 
    },
  ],
  [
 
    { 
      label: "PROCESS NO.", 
      rowSpan: 2, 
      id: "Process_Number" 
    },
    {
      label: "Program No.",
      rowSpan: 2,
      id: "Program_no",
    },
    {
      label: "PROCESS",
      rowSpan: 2,
      id: "Process_Name",
    },
    {
      label: "PRODUCT CHARACTERISTICS",
      rowSpan: 2,
      id: "Product_Characteristics",
    },
    {
      label: "STATUS",
      colSpan: 2,  // "OK" and "NOT OK" will be under this header
    },
    { 
      label: "REMARKS", 
      rowSpan: 2 
    },
  ],
  [
    { 
      label: "OK", 
      id: "ok" 
    },
    { 
      label: "NOT OK", 
      id: "Not_ok" 
    }
  ]
];

