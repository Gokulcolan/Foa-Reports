import { createSlice } from "@reduxjs/toolkit";

const userSlice = createSlice({
  name: "user",
  initialState: {
    partNumberDetail: [],
    partNumberIsLoading: false,
    foaDataDetail: [],
    foaDataIsLoading: false,
  },

  reducers: {
    partNumberReducer: (state, { payload }) => {
      console.log(payload, "payload");
      const { apiData, isLoading } = payload;
      state.partNumberDetail = apiData;
      state.partNumberIsLoading = isLoading;
    },

    foaDataReducer: (state, { payload }) => {
      console.log(payload, "payload");
      const { apiData, isLoading } = payload;
      state.foaDataDetail = apiData;
      state.foaDataIsLoading = isLoading;
    },

    // getSubAdminReducer: (state, { payload }) => {
    //   const { apiData, isLoading } = payload;
    //   state.getallSubAdminDetail = apiData;
    //   state.adminDataLoading = isLoading;
    // },

    // editSubAdminReducer: (state, { payload }) => {
    //   const { apiData, isLoading } = payload;
    //   state.subAdminDetail = apiData;
    //   state.adminDataLoading = isLoading;
    // },
  },
});

export const { partNumberReducer,foaDataReducer } = userSlice.actions;

export const userSelector = (state) => state.user;
export const userReducer = userSlice.reducer;
