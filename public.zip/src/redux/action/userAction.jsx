import { Apiservice } from "../api/Apiservice";
import { foaDataReducer, partNumberReducer } from "../slice/userSlice";

// import { partNumberReducer } from "../slice/adminSlice";

export function apiHelper(
  apiReducer,
  method,
  apiURL,
  data = "",
  
) {
  return async (dispatch) => {
    dispatch(apiReducer({ isLoading: true }));
    Apiservice(method, apiURL, data)
      .then((e) => {
        console.log(e, "demo");
        dispatch(apiReducer({ apiData: e?.data, isLoading: false }));
        // if (giveToast) {
        //   if (method === "POST")
        //     showToast(`${Toastmessage} Added Successfully`, "success");
        //   else if (method === "PUT") {
        //     showToast("Updated Data", "success");
        //   }
        // }
      })
      .catch((e) => {
        dispatch(apiReducer({ isLoading: false }));
        // showToast(e?.message, "error");
      });
  };
}

export function partNumberApi(payload) {
  return apiHelper(partNumberReducer, "POST", "/get_foa_varieties",payload );
}

export function foaDataApi(payload) {
  return apiHelper(foaDataReducer, "POST", "/get_foa_data",payload );
}

