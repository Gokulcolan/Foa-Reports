import React, { useState, useEffect, useRef } from "react";
import { useLocation } from "react-router";
import { UsermenuItems } from "../../../utils/constants/menuItems";
import ComponentHeadBar from "../../../components/common/componentHeadBar";
import {
  footer,
  headers,
  headers as initialHeaders,
} from "../../../utils/constants/tableData";
import CommonTable from "../../../components/common/commonTable";
import { useSelector } from "react-redux";
import { userSelector } from "../../../redux/slice/userSlice";
import { Button } from "@mui/material";
import DownloadIcon from "@mui/icons-material/Download";
import html2canvas from "html2canvas";
import jsPDF from "jspdf";

const Foa = () => {
  const [tableValue, setTableValue] = useState([]);
  const [apiResponse, setApiResponse] = useState([]);
  const [headersState, setHeadersState] = useState(initialHeaders);
  const [footerData, setFooterData] = useState([]);
  const tableRef = useRef(null); // Ref to capture the table
  const location = useLocation();
  const currentPath = location.pathname;
  
  const { foaDataDetail } = useSelector(userSelector);
  console.log(foaDataDetail, "foaDataDetail")
  console.log(apiResponse, "apiResponse")
  const currentMenuItem = UsermenuItems[0].isNested.find(
    (item) => item.path === currentPath
  );

  useEffect(() => {
    if (
      foaDataDetail &&
      foaDataDetail?.Data &&
      foaDataDetail?.Data?.length > 0
    ) {
      const response = foaDataDetail?.Data;
      setApiResponse(response);

      const firstItem = response[0];
      const partNo = firstItem.Part_No_Variety || " ";
      const date = firstItem.Date || "Date";
      const shift = firstItem.Shift || "Shift";
      const customer = firstItem.Customer || "Customer";
      const note = firstItem.Note || "";
      // Create a copy of the headers
      const updatedHeaders = headers?.map((row, rowIndex) => {
        return row?.map((col, colIndex) => {
          if (rowIndex === 0 && colIndex === 1) {
            // Update Date label
            return { ...col, label: `DATE: ${date}` };
          } else if (rowIndex === 0 && colIndex === 0) {
            // Update Shift label
            return {
              ...col,
              label: `M70 PRD/3 YTB STARTER MOTOR - ${partNo}`,
            };
          } else if (rowIndex === 1 && colIndex === 1) {
            // Update Shift label
            return { ...col, label: `SHIFT: ${shift}` };
          } else if (rowIndex === 2 && colIndex === 1) {
            // Update Shift label
            return { ...col, label: `CUSTOMER: ${customer}` };
          } else if (rowIndex === 3 && col.label === note) {
            return {
              ...col,
              style: { backgroundColor: "yellow", fontWeight: "bold" }, // Apply highlight style
            };
          }
          return col;
        });
      });
      setHeadersState(updatedHeaders);

      const footerResponse = [
        { label: firstItem.Remarks || "" },
        { label: firstItem.Quality_Auditor || "" },
        { label: firstItem.Quality_verifier || "" },
        { label: firstItem.Time || "" },
      ];

      setFooterData([footerResponse]); // Ensure it's an array of arrays
    }
  }, [foaDataDetail]);

  const handleDropdownChange = (e, rowIndex, colIndex) => {
    const newValue = e.target.value;
    const updatedTable = [...tableValue];
    updatedTable[rowIndex][colIndex].value = newValue;
    setTableValue(updatedTable);
  };

  const mapResponseToRows = (apiResponse, headers) => {
    return apiResponse.map((item) => {
      const row = [];
      headers.forEach((headerRow) => {
        headerRow.forEach((header) => {
          if (header.id) {
            row.push({ value: item[header.id] || "" });
          }
        });
      });
      return row;
    });
  };

  const tableData = mapResponseToRows(apiResponse, headersState);

  const downloadPDF = () => {
    const input = tableRef.current;

    html2canvas(input).then((canvas) => {
      const imgData = canvas.toDataURL("image/png");
      const pdf = new jsPDF("p", "mm", "a4");

      const imgWidth = 210; // A4 width in mm
      const pageHeight = 295; // A4 height in mm
      const imgHeight = (canvas.height * imgWidth) / canvas.width;
      let heightLeft = imgHeight;

      let position = 0;

      // Add the first page
      pdf.addImage(imgData, "PNG", 0, position, imgWidth, imgHeight);
      heightLeft -= pageHeight;

      // Add remaining pages if content height exceeds one page
      while (heightLeft >= 0) {
        position = heightLeft - imgHeight;
        pdf.addPage();
        pdf.addImage(imgData, "PNG", 0, position, imgWidth, imgHeight);
        heightLeft -= pageHeight;
      }

      // Save the PDF with the specified name
      pdf.save(`${currentMenuItem?.name}.pdf`);
    });
  };


  return (
    <div>
      <ComponentHeadBar mainHeading={currentMenuItem?.name} />
      <br />
      {apiResponse && apiResponse?.length > 0 ? (
        <div>
          <Button
            variant="contained"
            sx={{ float: "right", cursor: "pointer" }}
            onClick={downloadPDF}
          >
            <DownloadIcon sx={{ fontSize: "20px", marginRight: "4px" }} />{" "}
            Download
          </Button>
          <br />
          <br />
          <div ref={tableRef}>
            <CommonTable
              headers={headersState}
              rows={tableData}
              footer={footer}
              footerData={footerData}
              handleDropdownChange={handleDropdownChange}
            />
          </div>
        </div>
      ) : (
        <div style={{ textAlign: "center" }}>
          {/* "*please select Date,Shift and Part Number to view the table " */}
        </div>
      )}
    </div>
  );
};

export default Foa;
